# Klipy
 Low-latency, open source screen sharing tool.
 
# Todo:
 - Rewrite client script 
 - Add some kind of UI
 - Make it FASTER AND SMOOTHER
 - sleep
